package dev.dirronlive.parkour;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import dev.dirronlive.parkour.map.ParkourLayout;
import dev.dirronlive.parkour.world.ParkourActions;
import dev.dirronlive.parkour.world.ParkourWorld;
import dev.dirronlive.parkour.world.PlayerProgress;
import java.util.LinkedHashMap;
import java.util.Map;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.GameRules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Карта «Dirron Parkour: 100 комнат» — серверная часть мода. В одиночной
 * игре работает во встроенном сервере.
 */
public final class ParkourMod implements ModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("Dirron Parkour");

    /** Запуск выделенного сервера, который строит мир и выключается (сборка карты на GitHub). */
    public static final String BUILD_WORLD_PROPERTY = "dirronlive.buildWorldAndStop";

    @Override
    public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTED.register(ParkourMod::started);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            ParkourWorld.get(server).shutdown();
            ParkourWorld.forget(server);
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> ParkourWorld.get(server).tick());
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, environment) -> dispatcher.register(
                literal("parkour")
                        .then(literal("room").then(argument("n", IntegerArgumentType.integer(1, ParkourLayout.ROOMS))
                                .executes(c -> room(c, IntegerArgumentType.getInteger(c, "n")))))
                        .then(literal("reset").executes(ParkourMod::reset))
                        .then(literal("stats").executes(ParkourMod::stats))
                        .then(literal("build").requires(ParkourMod::owner).executes(ParkourMod::build))
                        .then(literal("action").requires(ParkourMod::owner)
                                .then(argument("id", StringArgumentType.word())
                                        .executes(c -> action(c, StringArgumentType.getString(c, "id"), ""))
                                        .then(argument("direction", StringArgumentType.word())
                                                .executes(c -> action(c, StringArgumentType.getString(c, "id"),
                                                        StringArgumentType.getString(c, "direction"))))))));
    }

    static boolean owner(ServerCommandSource source) {
        return source.hasPermissionLevel(2) || source.getServer().isSingleplayer();
    }

    static void started(MinecraftServer server) {
        ParkourWorld pw = ParkourWorld.get(server);
        pw.temp.repairAfterRestart(pw.world);
        if (pw.state.built) {
            pw.configureWorld();
            LOG.info("Dirron Parkour: карта найдена (база {} {} {})", pw.state.baseX, pw.state.baseY, pw.state.baseZ);
        }
        if (Boolean.getBoolean(BUILD_WORLD_PROPERTY)) {
            long t0 = System.currentTimeMillis();
            int blocks = pw.buildAll(0, 100, 0);
            server.getGameRules().get(GameRules.SPAWN_RADIUS).set(0, server);
            server.setDifficulty(net.minecraft.world.Difficulty.PEACEFUL, true);
            LOG.info("DIRRON_WORLD_BUILT rooms={} blocks={} ms={}", ParkourLayout.ROOMS, blocks,
                    System.currentTimeMillis() - t0);
            server.saveAll(false, true, true);
            server.stop(false);
        }
    }

    static ServerPlayerEntity player(CommandContext<ServerCommandSource> c) {
        ServerPlayerEntity player = c.getSource().getPlayer();
        if (player == null) c.getSource().sendError(Text.literal("Команду выполняет игрок"));
        return player;
    }

    static boolean requireMap(CommandContext<ServerCommandSource> c, ParkourWorld pw) {
        if (pw.state.built) return true;
        c.getSource().sendError(Text.literal("В этом мире нет карты. Открой мир DirronParkour или выполни /parkour build"));
        return false;
    }

    static int room(CommandContext<ServerCommandSource> c, int n) {
        ServerPlayerEntity player = player(c);
        if (player == null) return 0;
        ParkourWorld pw = ParkourWorld.get(c.getSource().getServer());
        if (!requireMap(c, pw)) return 0;
        int from = pw.progress(player).room;
        pw.moveToRoom(player, n);
        c.getSource().sendFeedback(() -> Text.literal("Комната " + from + " → " + n).formatted(Formatting.LIGHT_PURPLE), false);
        return 1;
    }

    static int reset(CommandContext<ServerCommandSource> c) {
        ServerPlayerEntity player = player(c);
        if (player == null) return 0;
        ParkourWorld pw = ParkourWorld.get(c.getSource().getServer());
        if (!requireMap(c, pw)) return 0;
        PlayerProgress p = pw.progress(player);
        p.falls = 0;
        p.ticks = 0;
        p.rescueCharges = 0;
        p.shieldCharges = 0;
        pw.lightEyes(false);
        pw.moveToRoom(player, 1);
        c.getSource().sendFeedback(() -> Text.literal("Прогресс сброшен: комната 1, падений 0, время 0:00"), false);
        return 1;
    }

    static int stats(CommandContext<ServerCommandSource> c) {
        ServerPlayerEntity player = player(c);
        if (player == null) return 0;
        ParkourWorld pw = ParkourWorld.get(c.getSource().getServer());
        if (!requireMap(c, pw)) return 0;
        PlayerProgress p = pw.progress(player);
        long s = p.ticks / 20;
        String text = String.format("Комната %d из 100 · падений %d · время %d:%02d%s · спасений %d · щитов %d",
                p.room, p.falls, s / 60, s % 60, p.finished ? " · ПОБЕДА" : "", p.rescueCharges, p.shieldCharges);
        c.getSource().sendFeedback(() -> Text.literal(text), false);
        return 1;
    }

    static int build(CommandContext<ServerCommandSource> c) {
        ParkourWorld pw = ParkourWorld.get(c.getSource().getServer());
        if (pw.state.built) {
            c.getSource().sendFeedback(() -> Text.literal("Карта уже построена в этом мире"), false);
        } else {
            int blocks = pw.buildAll(ParkourWorld.FALLBACK_X, ParkourWorld.FALLBACK_Y, ParkourWorld.FALLBACK_Z);
            c.getSource().sendFeedback(() -> Text.literal("Карта построена: 100 комнат, блоков " + blocks), true);
        }
        ServerPlayerEntity player = c.getSource().getPlayer();
        if (player != null) pw.moveToRoom(player, pw.progress(player).room);
        return 1;
    }

    static int action(CommandContext<ServerCommandSource> c, String id, String direction) {
        ServerPlayerEntity player = player(c);
        if (player == null) return 0;
        ParkourWorld pw = ParkourWorld.get(c.getSource().getServer());
        Map<String, Object> params = new LinkedHashMap<>();
        if (!direction.isEmpty()) params.put("direction", direction);
        ParkourActions.Outcome o = ParkourActions.apply(pw, player, id, params, "Команда");
        c.getSource().sendFeedback(() -> Text.literal(o.text()).formatted(o.ok() ? Formatting.GREEN : Formatting.RED), false);
        return o.ok() ? 1 : 0;
    }
}
