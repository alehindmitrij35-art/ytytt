import 'dart:convert';

import '../../core/events/gift_event.dart';

/// Протокол обмена с модом Dirronlive Bridge (JSON-сообщения по WebSocket).
///
/// Мод → программа:
///   {"type":"hello","protocol":1,"modVersion":"1.0.0",
///    "minecraftVersion":"1.21.1","worldReady":false}
///   {"type":"world","worldReady":true}
///   {"type":"ack","id":"…"}
///   {"type":"parkour","available":true,"room":12,"finished":false,"falls":3,"seconds":95}
///   {"type":"actionResult","id":"…","ok":true,"result":"Комната 12 → 11","room":11}
///
/// Программа → мод:
///   {"type":"welcome","app":"Dirronlive","protocol":2}
///   {"type":"gift","id":"…","viewerName":"…","giftName":"Роза","count":1}
///   {"type":"action","id":"…","action":"room_back","params":{"rooms":1},
///    "label":"Роза","viewerName":"Alex","test":false}
///   {"type":"countdown","id":"…","title":"…","seconds":10}
///   {"type":"countdownCancel","id":"…","text":"…"}
abstract final class LinkProtocol {
  static const version = 2;
  static const defaultPort = 8765;

  static String welcome() =>
      jsonEncode({'type': 'welcome', 'app': 'Dirronlive', 'protocol': version});

  /// Сообщение моду. [deliveryId] — уникальный ID этой отправки (по нему
  /// приходит подтверждение), [units] — сколько подарков применить сейчас.
  static String gift({
    required String deliveryId,
    required GiftEvent record,
    required int units,
    int? comboTotal,
  }) =>
      jsonEncode({
        'type': 'gift',
        'id': deliveryId,
        'viewerName': record.viewerName,
        'giftName': record.giftName,
        'count': units,
        if (comboTotal != null) 'combo': true,
        if (comboTotal != null) 'comboTotal': comboTotal,
      });

  static String action({
    required String id,
    required String action,
    required Map<String, Object?> params,
    required String label,
    required String viewerName,
    required bool test,
    int total = 1,
  }) =>
      jsonEncode({
        'type': 'action',
        'id': id,
        'action': action,
        'params': params,
        'label': label,
        'viewerName': viewerName,
        'test': test,
        'total': total,
      });

  static String countdown(String id, String title, int seconds) => jsonEncode(
      {'type': 'countdown', 'id': id, 'title': title, 'seconds': seconds});

  /// Погода и время: time — day/sunrise/sunset/night/midnight, weather — clear/rain/thunder,
  /// freeze — остановить смену дня и погоды.
  static String world({String? time, String? weather, bool? freeze}) => jsonEncode({
        'type': 'world',
        if (time != null) 'time': time,
        if (weather != null) 'weather': weather,
        if (freeze != null) 'freeze': freeze,
      });

  /// Сообщение чата TikTok для чата игры.
  static String chat(String name, String text, String color) =>
      jsonEncode({'type': 'chat', 'name': name, 'text': text, 'color': color});

  static String countdownCancel(String id, String text) =>
      jsonEncode({'type': 'countdownCancel', 'id': id, 'text': text});

  /// Разбирает сообщение мода. Возвращает `null` для мусора.
  static ModMessage? parse(Object? data) {
    if (data is! String) return null;
    Object? decoded;
    try {
      decoded = jsonDecode(data);
    } on FormatException {
      return null;
    }
    if (decoded is! Map) return null;
    switch (decoded['type']) {
      case 'hello':
        return ModHello(
          modVersion: _string(decoded['modVersion']),
          minecraftVersion: _string(decoded['minecraftVersion']),
          worldReady: decoded['worldReady'] == true,
          parkourActions: decoded['parkourActions'] == true,
          actionQueue: decoded['actionQueue'] == true,
        );
      case 'parkour':
        return ModParkour(ParkourInfo(
          available: decoded['available'] == true,
          room: _int(decoded['room']),
          finished: decoded['finished'] == true,
          falls: _int(decoded['falls']),
          seconds: _int(decoded['seconds']),
          roomFalls: _int(decoded['roomFalls']),
          bestRoom: _int(decoded['bestRoom']),
          bestSeconds: _int(decoded['bestSeconds']),
          queued: _int(decoded['queued']),
        ));
      case 'actionResult':
        final id = decoded['id'];
        if (id is! String || id.isEmpty) return null;
        return ModActionResult(
          id: id,
          ok: decoded['ok'] == true,
          result: _string(decoded['result']) ?? '',
          room: _int(decoded['room']),
          accepted: decoded.containsKey('accepted') ? _int(decoded['accepted']) : 1,
          done: decoded.containsKey('done') ? _int(decoded['done']) : (decoded['ok'] == true ? 1 : 0),
          queued: _int(decoded['queued']),
          finished: decoded['finished'] != false,
        );
      case 'world':
        return ModWorld(worldReady: decoded['worldReady'] == true);
      case 'ack':
        final id = decoded['id'];
        if (id is String && id.isNotEmpty) return ModAck(id);
        return null;
      default:
        return null;
    }
  }

  static String? _string(Object? value) =>
      value is String && value.isNotEmpty ? value : null;

  static int _int(Object? value) => value is num ? value.toInt() : 0;
}

/// Состояние карты «Dirron Parkour» в открытом мире.
class ParkourInfo {
  const ParkourInfo({
    required this.available,
    this.room = 0,
    this.finished = false,
    this.falls = 0,
    this.seconds = 0,
    this.roomFalls = 0,
    this.bestRoom = 0,
    this.bestSeconds = 0,
    this.queued = 0,
  });

  static const none = ParkourInfo(available: false);

  final bool available;
  final int room;
  final bool finished;
  final int falls;
  final int seconds;

  /// Падения в текущей комнате: попытка = roomFalls + 1.
  final int roomFalls;

  /// Рекорд забега: самая дальняя комната и лучшее время прохождения.
  final int bestRoom;
  final int bestSeconds;

  /// Сколько срабатываний ждёт в очереди мода.
  final int queued;
}

sealed class ModMessage {
  const ModMessage();
}

class ModHello extends ModMessage {
  const ModHello({
    this.modVersion,
    this.minecraftVersion,
    required this.worldReady,
    this.parkourActions = false,
    this.actionQueue = false,
  });

  final String? modVersion;
  final String? minecraftVersion;
  final bool worldReady;

  /// Мод 2.0+ умеет действия паркура.
  final bool parkourActions;

  /// Мод 2.1+: очередь серий без лимита.
  final bool actionQueue;
}

class ModParkour extends ModMessage {
  const ModParkour(this.info);

  final ParkourInfo info;
}

class ModActionResult extends ModMessage {
  const ModActionResult({
    required this.id,
    required this.ok,
    required this.result,
    this.room = 0,
    this.accepted = 1,
    this.done = 1,
    this.queued = 0,
    this.finished = true,
  });

  final String id;
  final bool ok;
  final String result;
  final int room;

  /// Сколько срабатываний принято в очередь, выполнено и ещё ждёт.
  final int accepted;
  final int done;
  final int queued;

  /// `false` — промежуточный прогресс серии.
  final bool finished;
}

class ModWorld extends ModMessage {
  const ModWorld({required this.worldReady});

  final bool worldReady;
}

class ModAck extends ModMessage {
  const ModAck(this.id);

  final String id;
}
