import 'package:flutter/material.dart';

import '../theme/app_colors.dart';

/// Крупная кнопка «Тестовый подарок» для левой колонки экрана «Эфир».
class TestGiftButton extends StatelessWidget {
  const TestGiftButton({super.key, required this.onPressed});

  static const buttonKey = Key('test-gift-button');

  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(18);
    return Semantics(
      button: true,
      label: 'Тестовый подарок',
      excludeSemantics: true,
      child: Material(
        color: Colors.transparent,
        borderRadius: radius,
        child: Ink(
          // Главная кнопка: фиолетовый #A78BFA, тёмный текст #160C26.
          decoration: BoxDecoration(
            borderRadius: radius,
            color: AppColors.accent,
            boxShadow: [
              BoxShadow(
                color: AppColors.accent.withAlpha(60),
                blurRadius: 22,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: InkWell(
            key: buttonKey,
            borderRadius: radius,
            onTap: onPressed,
            child: const Padding(
              padding: EdgeInsets.symmetric(horizontal: 18, vertical: 20),
              child: Column(
                children: [
                  Icon(
                    Icons.card_giftcard_rounded,
                    color: AppColors.onAccent,
                    size: 34,
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Тестовый подарок',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: AppColors.onAccent,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    '«Роза» ×1 от тестового зрителя',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: AppColors.onAccent,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
