import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/format.dart';
import '../../../features/parkour/gift_catalog.dart';
import '../../../features/parkour/parkour_rules.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import 'action_look.dart';

/// Отдельное окно «Каталог подарков TikTok»: крупная сетка, поиск,
/// «Обновить каталог» со сверкой. В режиме выбора одно нажатие на
/// карточку возвращает подарок.
class GiftCatalogDialog extends ConsumerStatefulWidget {
  const GiftCatalogDialog({super.key, this.pick = false});

  final bool pick;

  static Future<CatalogGift?> show(BuildContext context, {bool pick = false}) =>
      showDialog<CatalogGift>(context: context, builder: (_) => GiftCatalogDialog(pick: pick));

  @override
  ConsumerState<GiftCatalogDialog> createState() => _GiftCatalogDialogState();
}

class _GiftCatalogDialogState extends ConsumerState<GiftCatalogDialog> {
  final _search = TextEditingController();

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(giftCatalogProvider);
    final catalog = state.catalog;
    final query = _search.text;
    final selectable = catalog.selectable;
    final shown = selectable.where((g) => g.matchesQuery(query)).toList();
    final q = query.trim().toLowerCase();
    final starters = selectable.isEmpty || q.isNotEmpty
        ? starterGiftNames
            .where((n) => n.toLowerCase().contains(q) && !selectable.any((g) => g.displayName == n))
            .toList()
        : const <String>[];
    final size = MediaQuery.sizeOf(context);

    final String sourceLine;
    if (catalog.fetchedAt != null) {
      sourceLine = 'Все подарки TikTok: ${catalog.gifts.length} · обновлено ${formatDateTime(catalog.fetchedAt!)}. '
          'Список скачивается сам при запуске программы, эфир не нужен';
    } else if (catalog.gifts.isNotEmpty) {
      sourceLine = 'Все подарки TikTok: ${catalog.gifts.length} (список из установщика). '
          'Нажмите «Обновить каталог», чтобы получить цены и новинки для вашего региона';
    } else if (catalog.onlySeen) {
      sourceLine = 'Полный список ещё не скачан — показаны подарки, уже полученные в эфире '
          '(${catalog.seen.length}). Нажмите «Обновить каталог» — эфир для этого не нужен';
    } else {
      sourceLine = 'Список подарков ещё не скачан. Нажмите «Обновить каталог» — эфир для этого не нужен.';
    }

    return Dialog(
      key: const Key('gift-catalog'),
      backgroundColor: plum,
      insetPadding: const EdgeInsets.all(24),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: 1180, maxHeight: size.height - 48),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      widget.pick ? 'Выберите подарок' : 'Каталог подарков TikTok',
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.text),
                    ),
                  ),
                  FilledButton.icon(
                    key: const Key('catalog-refresh'),
                    onPressed: state.busy ? null : () => ref.read(giftCatalogProvider.notifier).refreshAndCheck(),
                    icon: state.busy
                        ? const SizedBox(
                            width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.sync_rounded, size: 18),
                    label: Text(state.busy ? 'Проверяю…' : 'Обновить каталог'),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    key: const Key('gift-catalog-close'),
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close_rounded, color: AppColors.textMuted),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                sourceLine,
                key: const Key('catalog-summary'),
                style: TextStyle(
                  fontSize: 13,
                  color: catalog.onlySeen ? AppColors.warning : AppColors.textMuted,
                  fontWeight: catalog.onlySeen ? FontWeight.w700 : FontWeight.w400,
                ),
              ),
              if (state.report != null) ...[
                const SizedBox(height: 10),
                CatalogReportView(report: state.report!, catalog: catalog),
              ],
              const SizedBox(height: 12),
              TextField(
                key: const Key('gift-search'),
                controller: _search,
                autofocus: widget.pick,
                onChanged: (_) => setState(() {}),
                style: const TextStyle(fontSize: 15, color: AppColors.text),
                decoration: appInputDecoration(
                  label: 'Поиск по названию',
                  hint: 'Роза, Лев, Rose…',
                  icon: Icons.search_rounded,
                ),
              ),
              const SizedBox(height: 12),
              Flexible(
                child: CustomScrollView(
                  shrinkWrap: true,
                  slivers: [
                    // Не подарок, а лайки или подписка (только при выборе для карточки).
                    if (widget.pick && q.isEmpty)
                      SliverToBoxAdapter(
                        child: Padding(
                          padding: const EdgeInsets.only(top: 14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Не подарок, а лайки или подписка',
                                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.text)),
                              const SizedBox(height: 8),
                              Wrap(spacing: 10, runSpacing: 10, children: [
                                for (final g in const [
                                  CatalogGift(id: likesTriggerId, name: 'Лайки', imageUrl: 'asset:assets/social/likes.png'),
                                  CatalogGift(
                                      id: followTriggerId, name: 'Подписка', imageUrl: 'asset:assets/social/follow.png'),
                                ])
                                  SizedBox(
                                    width: 160,
                                    height: 170,
                                    child: _GiftCard(
                                      key: Key('gift-option-${g.id}'),
                                      gift: g,
                                      onTap: () => Navigator.of(context).pop(g),
                                    ),
                                  ),
                              ]),
                              const SizedBox(height: 6),
                              const Text(
                                  'Лайки: сколько лайков на одно срабатывание — выставляется в карточке (сначала $likesPerTrigger). '
                                  'Подписка: каждая новая подписка.',
                                  style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
                              const SizedBox(height: 8),
                            ],
                          ),
                        ),
                      ),
                    if (shown.isNotEmpty)
                      SliverGrid(
                        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                          maxCrossAxisExtent: 170,
                          mainAxisExtent: 170,
                          crossAxisSpacing: 10,
                          mainAxisSpacing: 10,
                        ),
                        delegate: SliverChildBuilderDelegate(
                          (context, i) => _GiftCard(
                            key: Key('gift-option-${shown[i].id}'),
                            gift: shown[i],
                            onTap: widget.pick ? () => Navigator.of(context).pop(shown[i]) : null,
                          ),
                          childCount: shown.length,
                        ),
                      ),
                    if (starters.isNotEmpty) ...[
                      SliverToBoxAdapter(
                        child: Padding(
                          padding: const EdgeInsets.only(top: 14, bottom: 8),
                          child: Text(
                            selectable.isEmpty
                                ? 'Популярные подарки (пока список не скачан, срабатывают по названию)'
                                : 'Ещё по названию',
                            style: const TextStyle(fontSize: 12, color: AppColors.textFaint),
                          ),
                        ),
                      ),
                      SliverGrid(
                        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                          maxCrossAxisExtent: 170,
                          mainAxisExtent: 170,
                          crossAxisSpacing: 10,
                          mainAxisSpacing: 10,
                        ),
                        delegate: SliverChildListDelegate([
                          for (final name in starters)
                            _GiftCard(
                              key: Key('gift-option-$name'),
                              gift: CatalogGift(id: '', name: name),
                              onTap: widget.pick
                                  ? () => Navigator.of(context).pop(CatalogGift(id: '', name: name))
                                  : null,
                            ),
                        ]),
                      ),
                    ],
                    if (shown.isEmpty && starters.isEmpty)
                      const SliverToBoxAdapter(
                        child: Padding(
                          padding: EdgeInsets.all(24),
                          child: Center(
                            child: Text('Ничего не найдено', style: TextStyle(color: AppColors.textFaint)),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _GiftCard extends StatelessWidget {
  const _GiftCard({super.key, required this.gift, this.onTap});

  final CatalogGift gift;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: plumHigh,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            children: [
              const SizedBox(height: 4),
              GiftAvatar(imageUrl: gift.imageUrl, size: 64),
              const SizedBox(height: 8),
              Text(
                gift.displayName,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.text),
              ),
              const SizedBox(height: 2),
              Text(
                gift.diamonds > 0
                    ? '${gift.diamonds} монет'
                    : (gift.id == likesTriggerId || gift.id == followTriggerId ? 'бесплатно' : 'цена неизвестна'),
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: gift.diamonds > 0 ? AppColors.warning : AppColors.textFaint,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Итог сверки: три набора ID (коннектор, сохранённый, доступные для выбора).
class CatalogReportView extends StatelessWidget {
  const CatalogReportView({super.key, required this.report, required this.catalog});

  final CatalogReport report;
  final GiftCatalog catalog;

  @override
  Widget build(BuildContext context) {
    final ok = report.allAvailable;
    final lines = <String>[
      'Проверено: ${formatDateTime(report.checkedAt)}',
      if (report.fetched)
        'Коннектор: ${report.connectorCount} · сохранено: ${report.savedCount} · '
            'доступно для выбора: ${report.editorCount}'
      else if (catalog.fetchedAt != null)
        'Открыт последний успешный каталог от ${formatDateTime(catalog.fetchedAt!)} '
            '(${catalog.gifts.length} подарков).'
      else if (catalog.seen.isNotEmpty)
        'Открыты подарки, уже полученные в эфире (${catalog.seen.length}).'
      else
        'Сохранённого каталога нет.',
      if (report.onlySeen) 'Коннектор отдал только подарки, которые уже приходили в эфире.',
      if (report.missingInSaved.isNotEmpty) 'Не сохранились: ${report.missingInSaved.join(', ')}',
      if (report.missingInEditor.isNotEmpty) 'Нет среди доступных для выбора: ${report.missingInEditor.join(', ')}',
      if (report.added.isNotEmpty)
        'Новые с прошлой проверки: ${report.added.take(20).join(', ')}'
            '${report.added.length > 20 ? ' и ещё ${report.added.length - 20}' : ''}',
      if (report.removed.isNotEmpty)
        'Пропали из каталога: ${report.removed.take(20).join(', ')}'
            '${report.removed.length > 20 ? ' и ещё ${report.removed.length - 20}' : ''}',
      if (report.rulesWithoutGift.isNotEmpty)
        'Карточки с подарками не из этого эфира: ${report.rulesWithoutGift.join('; ')}',
    ];
    final title = ok
        ? 'Все подарки из каталога этого эфира доступны'
        : report.error != null
            ? (report.fetched ? 'Каталог получен с проблемой' : 'Каталог не обновлён')
            : 'Найдены расхождения';
    final color = ok ? AppColors.success : (report.error != null ? AppColors.danger : AppColors.warning);
    return Container(
      key: const Key('catalog-report'),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withAlpha(22),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withAlpha(120)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(ok ? Icons.check_circle_rounded : Icons.warning_amber_rounded, color: color, size: 20),
              const SizedBox(width: 8),
              Flexible(
                child: Text(title,
                    key: const Key('catalog-report-title'),
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: color)),
              ),
            ],
          ),
          if (report.error != null) ...[
            const SizedBox(height: 6),
            Text(
              '${_kindLabel(report.errorKind)}${report.error}',
              key: const Key('catalog-report-error'),
              style: const TextStyle(fontSize: 13, color: AppColors.text),
            ),
          ],
          const SizedBox(height: 4),
          for (final line in lines)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(line, style: const TextStyle(fontSize: 13, height: 1.35, color: AppColors.textMuted)),
            ),
        ],
      ),
    );
  }

  static String _kindLabel(String? kind) => switch (kind) {
        'network' => 'Ошибка сети: ',
        'offline' => 'Эфир не найден: ',
        'service' => 'Ошибка сервиса: ',
        'storage' => 'Ошибка сохранения: ',
        _ => '',
      };
}
