import 'package:dirronlive/features/settings/app_settings.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('normalizeTiktokNickname', () {
    final cases = <String, String>{
      'dirron': 'dirron',
      '  dirron  ': 'dirron',
      '@dirron': 'dirron',
      '  @dirron  ': 'dirron',
      '@@dirron': '@dirron',
      'dirron@': 'dirron@',
      'dirron live': 'dirron live',
      '': '',
      '   ': '',
      '@': '',
      '\t@dirron\n': 'dirron',
    };
    cases.forEach((input, expected) {
      test('«$input» → «$expected»', () {
        expect(normalizeTiktokNickname(input), expected);
      });
    });
  });

  test('настройки переживают сериализацию', () {
    const settings = AppSettings(tiktokNickname: 'dirron');
    expect(AppSettings.fromJson(settings.toJson()), settings);
  });

  test('ник из файла тоже нормализуется', () {
    final settings = AppSettings.fromJson({'tiktokNickname': ' @dirron '});
    expect(settings.tiktokNickname, 'dirron');
  });
}
