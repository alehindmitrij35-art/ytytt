import 'package:dirronlive/bootstrap.dart';
import 'package:dirronlive/core/events/event_source.dart';
import 'package:dirronlive/core/events/gift_event.dart';
import 'package:dirronlive/core/initial_data.dart';
import 'package:dirronlive/core/providers.dart';
import 'package:dirronlive/features/events/event_history_repository.dart';
import 'package:dirronlive/features/events/event_log.dart';
import 'package:dirronlive/features/events/test_gift.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/memory_store.dart';

Future<ProviderContainer> start(MemoryJsonStore store) async =>
    createAppContainer(await loadInitialData(store));

/// Дать шине доставить события и дождаться записи на диск.
Future<void> settle(ProviderContainer container) async {
  await Future<void>.delayed(Duration.zero);
  await container.read(eventLogProvider.notifier).flush();
}

void main() {
  test('первый запуск с пустой историей проходит без ошибок', () async {
    final store = MemoryJsonStore();
    final data = await loadInitialData(store);
    expect(data.history, isEmpty);
    expect(data.settings.tiktokNickname, '');
    expect(data.warnings, isEmpty);
  });

  test('три нажатия — три отдельных события, новые сверху, все на диске',
      () async {
    final store = MemoryJsonStore();
    final container = await start(store);
    final sender = container.read(testGiftSenderProvider);

    final first = sender.send();
    final second = sender.send();
    final third = sender.send();
    await settle(container);

    final events = container.read(eventLogProvider).events;
    expect(events.map((e) => e.id), [third.id, second.id, first.id]);
    expect(events.map((e) => e.id).toSet().length, 3);
    for (final e in events) {
      expect(e.source, EventSource.test);
      expect(e.viewerName, 'Тестовый зритель');
      expect(e.giftName, 'Роза');
      expect(e.count, 1);
    }
    expect(container.read(eventLogProvider).saveError, isNull);

    final onDisk = await EventHistoryRepository(store).load();
    expect(onDisk.events, events);
    container.dispose();
  });

  test('перезапуск восстанавливает ровно те же события без дублей', () async {
    final store = MemoryJsonStore();
    var container = await start(store);
    final sender = container.read(testGiftSenderProvider);
    sender
      ..send()
      ..send()
      ..send();
    await settle(container);
    final before = container.read(eventLogProvider).events;
    container.dispose();

    for (var restart = 0; restart < 3; restart++) {
      container = await start(store);
      await settle(container);
      expect(container.read(eventLogProvider).events, before);
      container.dispose();
    }
    final reloaded = await EventHistoryRepository(store).load();
    expect(reloaded.events.length, 3);
  });

  test('одно и то же событие, доставленное дважды, записывается один раз',
      () async {
    final store = MemoryJsonStore();
    final container = await start(store);
    final event = GiftEvent(
      id: generateEventId(),
      createdAt: DateTime.now(),
      source: EventSource.test,
      viewerName: 'Тестовый зритель',
      giftName: 'Роза',
      count: 1,
    );
    final bus = container.read(eventBusProvider);
    bus
      ..publish(event)
      ..publish(event);
    await settle(container);
    expect(container.read(eventLogProvider).events, [event]);
    container.dispose();
  });

  test('ошибка записи даёт понятное сообщение, событие остаётся видно',
      () async {
    final store = MemoryJsonStore()..failWrites = true;
    final container = await start(store);
    container.read(testGiftSenderProvider).send();
    await settle(container);

    final state = container.read(eventLogProvider);
    expect(state.events.length, 1);
    expect(state.saveError, contains('Не удалось сохранить историю событий'));

    // Диск снова доступен — следующее событие сохраняет всё и снимает ошибку.
    store.failWrites = false;
    container.read(testGiftSenderProvider).send();
    await settle(container);
    expect(container.read(eventLogProvider).saveError, isNull);
    expect((await EventHistoryRepository(store).load()).events.length, 2);
    container.dispose();
  });

  test('повреждённый файл истории откладывается в сторону', () async {
    final store = MemoryJsonStore();
    store.files[EventHistoryRepository.fileName] = '{ это не json';
    final data = await loadInitialData(store);
    expect(data.history, isEmpty);
    expect(data.warnings.single, contains('повреждён'));
    expect(store.files['${EventHistoryRepository.fileName}.broken'],
        '{ это не json');
  });

  test('повреждённые записи пропускаются, целые сохраняются', () async {
    final store = MemoryJsonStore();
    final good = GiftEvent(
      id: generateEventId(),
      createdAt: DateTime(2026, 11, 23, 12),
      source: EventSource.test,
      viewerName: 'Тестовый зритель',
      giftName: 'Роза',
      count: 1,
    );
    await EventHistoryRepository(store).save([good]);
    store.files[EventHistoryRepository.fileName] = store
        .files[EventHistoryRepository.fileName]!
        .replaceFirst('"events":[', '"events":[{"id":"x"},');
    final data = await loadInitialData(store);
    expect(data.history, [good]);
    expect(data.warnings.single, contains('1'));
  });

  test('комбо: шаги сливаются в одну запись, повторы игнорируются', () async {
    final store = MemoryJsonStore();
    final container = await start(store);
    final bus = container.read(eventBusProvider);
    GiftEvent step(int count, {bool active = true}) => GiftEvent(
          id: generateEventId(),
          createdAt: DateTime.now(),
          source: EventSource.test,
          viewerName: 'Тестовый зритель',
          giftName: 'Роза',
          count: count,
          comboId: 'c1',
          comboActive: active,
        );
    final first = step(1);
    bus
      ..publish(first)
      ..publish(step(2))
      ..publish(step(2)) // повтор шага
      ..publish(step(7))
      ..publish(step(7, active: false))
      ..publish(step(8)); // запоздавший «активный» шаг после конца
    container.read(testGiftSenderProvider).send(); // обычный подарок рядом
    await settle(container);

    final events = container.read(eventLogProvider).events;
    expect(events.length, 2);
    final combo = events.firstWhere((e) => e.isCombo);
    expect(combo.id, first.id);
    expect(combo.count, 8);
    expect(combo.comboActive, isFalse);
    expect(combo.giftText, 'Роза ×8');

    final reloaded = await loadInitialData(store);
    expect(reloaded.history.firstWhere((e) => e.isCombo).count, 8);
    container.dispose();
  });
}
